import java.util.Arrays;

import edu.princeton.cs.algs4.Stack;

public class Board {
    private int[][] board;
    private int n; 
    private int manhattan = -1;
	public Board(int[][] blocks) {
    	if (blocks == null)  {throw new IllegalArgumentException();}
    	n = blocks.length;
    	board = new int[n][];  
        for (int i=0; i<n; i++){  
            board[i] = Arrays.copyOf(blocks[i], n);  
        }
    }                // construct a board from an n-by-n array of blocks
                      // (where blocks[i][j] = block in row i, column j)
    public int dimension() {
    	return n;
    }                 // board dimension n
    public int hamming() {
    	int hamming = 0;
    	int goal = 1;
    	for (int i = 0; i < n; i++) {
    		for (int j = 0; j < n; j++) {
    			if (goal < n*n && board[i][j] != goal) {
    				hamming += 1;
    			}
    			goal = goal + 1;
    		}
    	}
    	return hamming;
    }                 // number of blocks out of place
    public int manhattan() {
    	if (manhattan >= 0)  {return manhattan;}
    	manhattan = 0;
    	int row;
    	int col;
    	for (int i = 0; i < n; i++) {
    		for (int j = 0; j < n; j++) {
    			if (board[i][j] != 0 && board[i][j] != n*i+j+1) {
    			row = (board[i][j]-1) / n;
    			col = (board[i][j]-1) % n;
    			manhattan += Math.abs(row-i) + Math.abs(col-j);
    		    }
    	    }
    	}
    	return manhattan;
    }                // sum of Manhattan distances between blocks and goal
    public boolean isGoal() {
    	return this.hamming() == 0;
    }              // is this board the goal board?
    public Board twin() {
    	if (n <= 1)  {return null;}
    	int[][] twin = Copy();
    	if (twin[n-1][n-1] != 0 && twin[n-1][n-2] != 0) {
    	    exch(twin, n-1, n-1, n-1, n-2);
    	}
    	else {
    		exch(twin, 0, 0, 0, 1);
    	}
    	return new Board(twin);
    }                   // a board that is obtained by exchanging any pair of blocks
    public boolean equals(Object y) {
    	if (y == null)  return false;
    	if (this == y)  return true;
    	if (y instanceof Board) {
    		Board that = (Board) y;
    		if (that.board.length != this.board.length)  {return false;}
    		for (int i = 0; i < this.board.length; i++) {
                if (that.board[i].length != this.board[i].length) {return false;}
    			for (int j = 0; j < this.board[i].length; j++) {
                	if (that.board[i][j] != this.board[i][j]) {
                		return false;
                	}
                }
    		}    
            return true;
    	}
    	return false;
    }            // does this board equal y?
    public Iterable<Board> neighbors() {
    	Stack<Board> neighbors = new Stack<Board>();
    	int blank_i = 0;
    	int blank_j = 0;
    	for(int i = 0; i < n; i++) {
    		for(int j = 0; j < n; j++) {
    			if (board[i][j] == 0) {
    				blank_i = i;
    				blank_j = j;
                    break;
             	}
            }
 	    }
    	if (blank_i != 0) {
    		int[][] neighbor1 = Copy();
      		exch(neighbor1,blank_i,blank_j,blank_i-1,blank_j);
      		neighbors.push(new Board(neighbor1));
      	}
      	if (blank_i != n-1) {
      		int[][] neighbor2 = Copy();
      		exch(neighbor2,blank_i,blank_j,blank_i+1,blank_j);
      		neighbors.push(new Board(neighbor2));
      	}
      	if (blank_j != 0) {
      		int[][] neighbor3 = Copy();
      		exch(neighbor3,blank_i,blank_j,blank_i,blank_j-1);
      		neighbors.push(new Board(neighbor3));
      	}
      	if (blank_j != n-1) {
      		int[][] neighbor4 = Copy();
      		exch(neighbor4,blank_i,blank_j,blank_i,blank_j+1);
      		neighbors.push(new Board(neighbor4));
      	}
    	return neighbors;
    }            // all neighboring boards
    private static void exch(int[][] a, int row1, int col1, int row2, int col2) {
    	if (a == null)  return;
    	int temp = a[row1][col1];
    	a[row1][col1] = a[row2][col2];
    	a[row2][col2] = temp;
    }
    private int[][] Copy(){  
        int[][] result = new int[n][];  
        for (int i=0; i<n; i++){  
            result[i] = Arrays.copyOf(this.board[i], n);  
        }  
        return result;  
    }  
    public String toString() {
        StringBuilder s = new StringBuilder();
        s.append(n + "\n");
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                s.append(String.format("%2d ", board[i][j]));
            }
            s.append("\n");
        }
        return s.toString();
    }            // string representation of this board (in the output format specified below)
}