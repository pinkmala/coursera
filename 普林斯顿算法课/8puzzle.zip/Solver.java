import edu.princeton.cs.algs4.Stack;
import edu.princeton.cs.algs4.In;
import edu.princeton.cs.algs4.MinPQ;
import edu.princeton.cs.algs4.StdOut;

public class Solver {
    private SearchNode solutionNode;
    private boolean isSolved;
	private class SearchNode implements Comparable<SearchNode> {
    	private Board core;
    	private int moves;
    	private SearchNode parent;
    	public SearchNode(Board core, int moves, SearchNode parent) {
    		this.core = core;
    		this.moves = moves;
    		this.parent = parent;
    	}
    	public int compareTo(SearchNode that) {
    		return (this.core.manhattan()+this.moves)-(that.core.manhattan()+that.moves);
    	}
    } 
	
	public Solver(Board initial) {
    	if (initial == null)  {throw new IllegalArgumentException();}
    	if (initial.dimension() == 1)  {
    		isSolved = true; 
    		solutionNode = new SearchNode(initial, 0, null);
    	}
    	SearchNode initialNode = new SearchNode(initial, 0, null);
    	SearchNode initialNodeTwin = new SearchNode(initial.twin(), 0, null);
    	MinPQ<SearchNode> candidates = new MinPQ<SearchNode>();
    	MinPQ<SearchNode> candidatesTwin = new MinPQ<SearchNode>();
    	candidates.insert(initialNode);
    	candidatesTwin.insert(initialNodeTwin);
    	while (true) {
    		SearchNode min = candidates.delMin();
    		if(min.core.isGoal()) {
    			solutionNode = min;
    			isSolved = true;
    			return;
    		}
    		for (Board neighbor: min.core.neighbors()) {
    			if (min.moves == 0 || !neighbor.equals(min.parent.core)) {
    				candidates.insert(new SearchNode(neighbor, min.moves+1, min));
    			}
    		}
    		SearchNode minTwin = candidatesTwin.delMin();
    		if(minTwin.core.isGoal()) {
    			solutionNode = minTwin;
    			isSolved = false;
    			return;
    		}
    		for (Board neighbor: minTwin.core.neighbors()) {
    			if (minTwin.moves == 0 || !neighbor.equals(minTwin.parent.core)) {
    				candidatesTwin.insert(new SearchNode(neighbor, minTwin.moves+1, minTwin));
    			}
    		}
    	}
    }          // find a solution to the initial board (using the A* algorithm)
    public boolean isSolvable() {
    	return isSolved;
    }            // is the initial board solvable?
    public int moves() {
    	if (!isSolved)  {return -1;}
    	return solutionNode.moves;
    }                    // min number of moves to solve initial board; -1 if unsolvable
    public Iterable<Board> solution() {
    	if (!isSolved)  {return null;}
    	Stack<Board> solution = new Stack<Board>();
    	SearchNode pathNode = solutionNode;
    	while (pathNode != null) {
    	solution.push(pathNode.core);
    	pathNode = pathNode.parent;
    	}
    	return solution;
    }     // sequence of boards in a shortest solution; null if unsolvable
    public static void main(String[] args) {
    	// create initial board from file
        In in = new In(args[0]);
        int n = in.readInt();
        int[][] blocks = new int[n][n];
        for (int i = 0; i < n; i++)
            for (int j = 0; j < n; j++)
                blocks[i][j] = in.readInt();
        Board initial = new Board(blocks);

        // solve the puzzle
        Solver solver = new Solver(initial);

        // print solution to standard output
        if (!solver.isSolvable())
            StdOut.println("No solution possible");
        else {
            StdOut.println("Minimum number of moves = " + solver.moves());
            for (Board board : solver.solution())
                StdOut.println(board);
        }
    }// solve a slider puzzle (given below)
}