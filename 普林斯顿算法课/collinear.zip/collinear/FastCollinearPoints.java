import java.util.ArrayList;
import java.util.Arrays;

public class FastCollinearPoints {
	private int count = 0;
	private ArrayList<LineSegment> lines;
	public FastCollinearPoints(Point[] points) {
		if (points == null)  {throw new IllegalArgumentException();}
		int length = points.length;
		for(int i=0; i<length; i++) {
			if (points[i] == null)  {throw new IllegalArgumentException();}
		}
		Point[] copyInput = Arrays.copyOf(points, length);
		Arrays.sort(copyInput);
		for(int i=0; i<length-1; i++) {
			if (copyInput[i].slopeTo(copyInput[i+1]) == Double.NEGATIVE_INFINITY)  {throw new IllegalArgumentException();}
		}
		Point[] copy = Arrays.copyOf(copyInput, length);
		lines = new ArrayList<LineSegment>();
		for (int i=0; i < length; i++) {
			Arrays.sort(copy, copyInput[i].slopeOrder());
			int equals = 1;
			for (int j=1; j < length-1; j++) {
				if (Double.compare(copy[0].slopeTo(copy[j]), copy[0].slopeTo(copy[j+1])) == 0) {
					equals++;
					if(j == length-2 && equals >= 3) {
						Arrays.sort(copy,j-equals+2,length);
						if (copy[0].compareTo(copy[j-equals+2]) < 0) {
						lines.add(new LineSegment(copy[0], copy[j+1]));
						count++;
						}
					}
				}
				else {
					if(equals >= 3) {
						Arrays.sort(copy,j-equals+1,j+1);
						if (copy[0].compareTo(copy[j-equals+1]) < 0) {
						lines.add(new LineSegment(copy[0], copy[j]));
						count++;
						}
					}
					equals = 1;
				}
			}
				
		}
	}    // finds all line segments containing 4 or more points
	public int numberOfSegments() {
		return count;
	}        // the number of line segments
	public LineSegment[] segments() {
		return lines.toArray(new LineSegment[count]);
	}                // the line segments
}