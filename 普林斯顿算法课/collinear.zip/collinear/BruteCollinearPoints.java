import java.util.ArrayList;
import java.util.Arrays;

import edu.princeton.cs.algs4.Insertion;

public class BruteCollinearPoints {
	private int count = 0;
	private ArrayList<LineSegment> lines = new ArrayList<LineSegment>();
	public BruteCollinearPoints(Point[] points) {
		if (points == null)  {throw new IllegalArgumentException();}
		int length = points.length;
		for(int i=0; i<length; i++) {
			if (points[i] == null)  {throw new IllegalArgumentException();}
		}
		Point[] copyInput = Arrays.copyOf(points, length);
		Arrays.sort(copyInput);
		for(int i=0; i<length-1; i++) {
			if (copyInput[i].slopeTo(copyInput[i+1]) == Double.NEGATIVE_INFINITY)  {throw new IllegalArgumentException();}
		}
		if (length >= 4) {
			for(int i=0; i<length-3; i++) {
				for(int j=i+1; j<length-2; j++) {
					for(int k=j+1; k<length-1; k++) {
					    for(int l=k+1; l<length; l++) {
						    if(Double.compare(points[i].slopeTo(points[j]), points[j].slopeTo(points[k])) == 0
						       && Double.compare(points[j].slopeTo(points[k]), points[k].slopeTo(points[l])) == 0) {
							    Point[] pointsOfLine = new Point[4];
							    pointsOfLine[0] = points[i];
							    pointsOfLine[1] = points[j];
							    pointsOfLine[2] = points[k];
							    pointsOfLine[3] = points[l];
						    	Insertion.sort(pointsOfLine);
						    	lines.add(new LineSegment(pointsOfLine[0],pointsOfLine[3]));
						    	count++;
						    } 
					    }
				    }
			    }
		    }
		}
	}   // finds all line segments containing 4 points
	public int numberOfSegments() {
		return count;
	}       // the number of line segments
	public LineSegment[] segments() {
		return lines.toArray(new LineSegment[count]);
	}               // the line segments
}
