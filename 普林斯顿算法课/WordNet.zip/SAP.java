import edu.princeton.cs.algs4.BreadthFirstDirectedPaths;
import edu.princeton.cs.algs4.Digraph;

public class SAP {
       private final Digraph G;
	   // constructor takes a digraph (not necessarily a DAG)
	   public SAP(Digraph G) {
		   if (G == null)  {throw new IllegalArgumentException();}
		   this.G = new Digraph(G.V());
		   for (int i=0; i < G.V(); i++) {
			   for (int v: G.adj(i)){
			       this.G.addEdge(i, v);
			   }
		   }
	   }

	   // length of shortest ancestral path between v and w; -1 if no such path
	   public int length(int v, int w) {
		   if (v < 0 || v >= G.V() || w < 0 || w >= G.V())  {throw new IllegalArgumentException();}
		   BreadthFirstDirectedPaths bfsv = new BreadthFirstDirectedPaths(G, v);
		   BreadthFirstDirectedPaths bfsw = new BreadthFirstDirectedPaths(G, w);
		   int min = Integer.MAX_VALUE;
		   boolean hasPath = false;
		   for (int i = 0; i < G.V(); i++) {
		       if (bfsv.hasPathTo(i) && bfsw.hasPathTo(i)) {
		    	   int length = bfsv.distTo(i) + bfsw.distTo(i);
		    	   if (length < min) {
		    		   min = length;
		    		   hasPath = true;
		    	   }
		       }
		   }
		   return hasPath? min : -1;
	   }

	   // a common ancestor of v and w that participates in a shortest ancestral path; -1 if no such path
	   public int ancestor(int v, int w) {
		   if (v < 0 || v >= G.V() || w < 0 || w >= G.V())  {throw new IllegalArgumentException();}
		   BreadthFirstDirectedPaths bfsv = new BreadthFirstDirectedPaths(G, v);
		   BreadthFirstDirectedPaths bfsw = new BreadthFirstDirectedPaths(G, w);
		   int min = Integer.MAX_VALUE;
		   int ancestor = -1;
		   for (int i = 0; i < G.V(); i++) {
		       if (bfsv.hasPathTo(i) && bfsw.hasPathTo(i)) {
		    	   int length = bfsv.distTo(i) + bfsw.distTo(i);
		    	   if (length < min) {
		    		   min = length;
		    		   ancestor = i;
		    	   }
		       }
		   }
		   return ancestor;
	   }

	   // length of shortest ancestral path between any vertex in v and any vertex in w; -1 if no such path
	   public int length(Iterable<Integer> v, Iterable<Integer> w) {
		   if (v == null || w == null)  {throw new IllegalArgumentException();}
		   BreadthFirstDirectedPaths bfsv = new BreadthFirstDirectedPaths(G, v);
		   BreadthFirstDirectedPaths bfsw = new BreadthFirstDirectedPaths(G, w);
		   int min = Integer.MAX_VALUE;
		   boolean hasPath = false;
		   for (int i = 0; i < G.V(); i++) {
		       if (bfsv.hasPathTo(i) && bfsw.hasPathTo(i)) {
		    	   int length = bfsv.distTo(i) + bfsw.distTo(i);
		    	   if (length < min) {
		    		   min = length;
		    		   hasPath = true;
		    	   }
		       }
		   }
		   return hasPath? min : -1;
	   }

	   // a common ancestor that participates in shortest ancestral path; -1 if no such path
	   public int ancestor(Iterable<Integer> v, Iterable<Integer> w) {
		   if (v == null || w == null)  {throw new IllegalArgumentException();}
		   BreadthFirstDirectedPaths bfsv = new BreadthFirstDirectedPaths(G, v);
		   BreadthFirstDirectedPaths bfsw = new BreadthFirstDirectedPaths(G, w);
		   int min = Integer.MAX_VALUE;
		   int ancestor = -1;
		   for (int i = 0; i < G.V(); i++) {
		       if (bfsv.hasPathTo(i) && bfsw.hasPathTo(i)) {
		    	   int length = bfsv.distTo(i) + bfsw.distTo(i);
		    	   if (length < min) {
		    		   min = length;
		    		   ancestor = i;
		    	   }
		       }
		   }
		   return ancestor;
	   }

	   // do unit testing of this class
	   public static void main(String[] args) {
		   
	   }
}