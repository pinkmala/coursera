import edu.princeton.cs.algs4.In;
import edu.princeton.cs.algs4.StdOut;

public class Outcast {
	private WordNet wordnet;   
	public Outcast(WordNet wordnet) {
		this.wordnet = wordnet;   
	}        // constructor takes a WordNet object
	public String outcast(String[] nouns) {
		int[] dist = new int[nouns.length];
		for (int i = 0; i < nouns.length-1; i++) {
			for (int j = i+1; j < nouns.length; j++) {
				int dist_ij = wordnet.distance(nouns[i], nouns[j]);
				if (dist_ij == -1)  {
					dist[i] = dist[j] = Integer.MAX_VALUE;
				}
				else {
					dist[i] += dist_ij;
					dist[j] += dist_ij;
				}
			}
		}
		int max = 0;
		int maxindex = -1;
		for (int i = 0; i < dist.length; i++) {
			if (dist[i] >= max) {
			    max = dist[i];
			    maxindex = i;
			}
		}
		return nouns[maxindex];
	}  // given an array of WordNet nouns, return an outcast
	public static void main(String[] args) {
	    WordNet wordnet = new WordNet(args[0], args[1]);
	    Outcast outcast = new Outcast(wordnet);
	    for (int t = 2; t < args.length; t++) {
	        In in = new In(args[t]);
	        String[] nouns = in.readAllStrings();
	        StdOut.println(args[t] + ": " + outcast.outcast(nouns));
	    }
	}
}