import java.util.ArrayList;
import java.util.HashMap;
//import java.util.HashSet;

import edu.princeton.cs.algs4.Bag;
import edu.princeton.cs.algs4.Digraph;
import edu.princeton.cs.algs4.In;
import edu.princeton.cs.algs4.Queue;

public class WordNet {
       private final Digraph net;
	   private final HashMap<String, Bag<Integer>> ids;
	   private final ArrayList<String> synsetsList; 
	   public WordNet(String synsets, String hypernyms) {
		   if (synsets == null || hypernyms == null)  {throw new IllegalArgumentException();}
		   In synset = new In(synsets);
		   ids = new HashMap<String, Bag<Integer>>(); 
		   synsetsList = new ArrayList<String>();
		   //HashSet<Integer> idset = new HashSet<Integer>();
		   int count = 0;
		   while (!synset.isEmpty()) {
		       String line = synset.readLine();
		       String[] fields = line.split(",");
		       int synset_id = Integer.parseInt(fields[0]); 
		       synsetsList.add(synset_id, fields[1]);
		       //idset.add(synset_id);
		       String[] noun_list = fields[1].split(" ");
		       for (int i = 0; i < noun_list.length; i++) {
		           if (!ids.containsKey(noun_list[i])) {
		        	   Bag<Integer> bag = new Bag<Integer>();
		        	   bag.add(synset_id);
		        	   ids.put(noun_list[i], bag);
		           } 
		           else{
		        	   Bag<Integer> idBag = ids.get(noun_list[i]);
		        	   idBag.add(synset_id);
		           }
		       }
		       count++;
		   }
		   net = new Digraph(count);
		   In hypernym = new In(hypernyms);
		   while (!hypernym.isEmpty()) {
			   String line = hypernym.readLine();
		       String[] fields = line.split(",");
		       int id = Integer.parseInt(fields[0]);
		       //idset.remove(id);
		       for (int i = 1; i < fields.length; i++) {
			       net.addEdge(id, Integer.parseInt(fields[i]));
		       }
		   }
		   //if (idset.size() != 1)  {throw new IllegalArgumentException();}
		   //checkRootedDAG((int)idset.toArray()[0]);
	  }          // constructor takes the name of the two input files

	   // returns all WordNet nouns
	   /*private void checkRootedDAG(int root) {
		   boolean[] marked = new boolean[net.V()];
		   int[] distTo = new int[net.V()]; 
		   Queue<Integer> nodes = new Queue<Integer>();
		   nodes.enqueue(root);
		   marked[root] = true;
		   distTo[root] = 0;
		   while (!nodes.isEmpty()) {
			   int node = nodes.dequeue();
			   for (int v: net.reverse().adj(node)) {
				   if (marked[v] == true && distTo[v] != distTo[node] + 1)  {throw new IllegalArgumentException();}
				   nodes.enqueue(v);
				   distTo[v] = distTo[node] + 1;
				   marked[v] = true;
			   }
		   }
	   }*/
	   public Iterable<String> nouns() {
		   return ids.keySet();
	   }

	   // is the word a WordNet noun?
	   public boolean isNoun(String word) {
		   if (word == null)  {throw new IllegalArgumentException();}
		   return ids.containsKey(word);
	   }

	   // distance between nounA and nounB (defined below)
	   public int distance(String nounA, String nounB) {
		   if (nounA == null || nounB == null || !isNoun(nounA) || !isNoun(nounB))  {throw new IllegalArgumentException();}
		   Bag<Integer> idAs = ids.get(nounA);
		   Bag<Integer> idBs = ids.get(nounB);
		   SAP sap = new SAP(net);
		   return sap.length(idAs, idBs);
	   }

	   // a synset (second field of synsets.txt) that is the common ancestor of nounA and nounB
	   // in a shortest ancestral path (defined below)
	   public String sap(String nounA, String nounB) {
		   if (nounA == null || nounB == null || !isNoun(nounA) || !isNoun(nounB))  {throw new IllegalArgumentException();}
		   Bag<Integer> idAs = ids.get(nounA);
		   Bag<Integer> idBs = ids.get(nounB);
		   SAP sap = new SAP(net);
		   int ancestor = sap.ancestor(idAs, idBs);
		   return  synsetsList.get(ancestor);
	   }

	   // do unit testing of this class
	   public static void main(String[] args) {
		   
	   }
}