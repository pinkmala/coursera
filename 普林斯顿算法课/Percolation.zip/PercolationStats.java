import edu.princeton.cs.algs4.StdRandom;
import edu.princeton.cs.algs4.StdStats;
import edu.princeton.cs.algs4.StdOut;
public class PercolationStats {
	private static final double SIGMA = 1.96;
	private final int times;
	private final int N;
	private final double mean;
	private final double stddev;
	public PercolationStats(int n, int trials) {
		if (n < 1 || trials < 1) {
			throw new IllegalArgumentException("Index should be >= 1");
		}
		N = n;
		times = trials;
		double[] thresholdOfOpenSites = new double[times];
		for (int i = 0; i < times; i++) {
			Percolation trial = new Percolation(N);
			while (!trial.percolates()) {
				int row = StdRandom.uniform(N)+1;
				int col = StdRandom.uniform(N)+1;
				trial.open(row, col);
			}
			thresholdOfOpenSites[i] = (double) trial.numberOfOpenSites()/(N*N);
		}
		mean = StdStats.mean(thresholdOfOpenSites);
		stddev = StdStats.stddev(thresholdOfOpenSites);
	}    // perform trials independent experiments on an n-by-n grid
	   public double mean() {
		   return mean;
	   }                          // sample mean of percolation threshold
	   public double stddev() {
		   return stddev;
	   }                        // sample standard deviation of percolation threshold
	   public double confidenceLo() {
		   return mean-SIGMA*stddev/Math.sqrt(times);
	   }                  // low  endpoint of 95% confidence interval
	   public double confidenceHi() {
		   return mean+SIGMA*stddev/Math.sqrt(times);
	   }                  // high endpoint of 95% confidence interval

	   public static void main(String[] args) {
		   int n = Integer.parseInt(args[0]);
		   int trials = Integer.parseInt(args[1]);
		   PercolationStats experiment = new PercolationStats(n, trials);
		   StdOut.println("mean\t="+experiment.mean());
		   StdOut.println("stddev\t="+experiment.stddev());
		   StdOut.println("95% confidence interval\t=["+experiment.confidenceLo()+","+experiment.confidenceHi()+"]");
	   }        // test client (described below)
}
