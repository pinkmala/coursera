import edu.princeton.cs.algs4.WeightedQuickUnionUF;

public class Percolation {
	private final boolean[] symbol;
	private int numbers = 0;
	private final WeightedQuickUnionUF grid;
	private final WeightedQuickUnionUF fullUF;
	private final int N;
	public Percolation(int n) {      // create n-by-n grid, with all sites blocked
		if (n < 1) {
			throw new IllegalArgumentException("index should be >= 1");
		}
		N = n;
		grid = new WeightedQuickUnionUF(N*N+2);
		fullUF = new WeightedQuickUnionUF(N*N+1);
		symbol = new boolean[N*N+2];
		symbol[0] = symbol[N*N+1] = true;	// 0--blocked, 1--open
	}
	
	public void open(int row, int col) {
		if (row < 1 || row > N || col < 1 || col > N) {
			throw new IllegalArgumentException("Index is not between 1 and " + N);
		}
		int opened = N*(row-1) + col;
		if (symbol[opened]) {
			return;
		}
		else {
			symbol[opened] = true;
			numbers++;
			if (col != 1 && isOpen(row, col-1)) {
				grid.union(N*(row-1)+col, N*(row-1)+(col-1));
				fullUF.union(N*(row-1)+col, N*(row-1)+(col-1));
			}
			if (col != N && isOpen(row, col+1)) {
				grid.union(N*(row-1)+col, N*(row-1)+(col+1));
				fullUF.union(N*(row-1)+col, N*(row-1)+(col+1));
			}
			if (row != 1 && isOpen(row-1, col)) {
				grid.union(N*(row-1)+col, N*(row-2)+col);
				fullUF.union(N*(row-1)+col, N*(row-2)+col);
			}
			if (row != N && isOpen(row+1, col)) {
				grid.union(N*(row-1)+col, N*row+col);
				fullUF.union(N*(row-1)+col, N*row+col);
			}
			if (row == 1) {
				grid.union(N*(row-1)+col, 0);
				fullUF.union(N*(row-1)+col, 0);
			}
			if (row == N) {
				grid.union(N*(row-1)+col, N*N+1);
			}
		}
	}    // open site (row, col) if it is not open already
	
	public boolean isOpen(int row, int col) {
		if (row < 1 || row > N || col < 1 || col > N) {
			throw new IllegalArgumentException("Index is not between 1 and " + N);
		}
		int site = N*(row-1) + col;
		return (symbol[site]);
	}  // is site (row, col) open?
	
	public boolean isFull(int row, int col) {
		if (row < 1 || row > N || col < 1 || col > N) {
			throw new IllegalArgumentException("Index is not between 1 and " + N);
		}
		int site = N*(row-1) + col;
		return fullUF.connected(0, site);
	}  // is site (row, col) full?
	
	public int numberOfOpenSites() {
		return numbers;
	}       // number of open sites
	
	public boolean percolates() {
		return grid.connected(0, N*N+1);
	}              // does the system percolate?
}