import java.util.Iterator;
import java.util.NoSuchElementException;
import edu.princeton.cs.algs4.StdRandom;

public class RandomizedQueue<Item> implements Iterable<Item> {
	private Item[] rdQueue;
	private int count;
	public RandomizedQueue() {
		rdQueue = (Item[]) new Object[2];
		count = 0;
	}                // construct an empty randomized queue
	public boolean isEmpty() {
		return count == 0;
	}             // is the randomized queue empty?
	public int size() {
		return count;
	}                       // return the number of items on the randomized queue
	private void resize(int length) {
		Item[] temp = (Item[]) new Object[length];
	    for(int i = 0; i < count; i++) {
	    	temp[i] = rdQueue[i];
	    }
	    rdQueue = temp;
	}
	public void enqueue(Item item) {
		if (item == null)  throw new IllegalArgumentException();
		if (count == rdQueue.length) {
			resize(2*rdQueue.length);
		}
		rdQueue[count] = item;
		count++;
	}           // add the item
	public Item dequeue() {
		if(isEmpty()) {throw new NoSuchElementException();}
		if (count == rdQueue.length/4) {
			resize(rdQueue.length/2);
		}
		int rdindex = StdRandom.uniform(count); 
		Item temp = rdQueue[rdindex];
		rdQueue[rdindex] = rdQueue[count-1];
		rdQueue[count-1] = null;
		count--;
		return temp;
	}                    // remove and return a random item
	public Item sample() {
		if(isEmpty()) {throw new NoSuchElementException();}
		int rdindex = StdRandom.uniform(count); 
		return rdQueue[rdindex];
	}                    // return a random item (but do not remove it)
	public Iterator<Item> iterator() {
		return new RDArrayIterator();
	}        // return an independent iterator over items in random order
	private class RDArrayIterator implements Iterator<Item> {
		private int n;
		private Item[] a;
		public RDArrayIterator() {
			n = 0;
			a = (Item[]) new Object[count];
			for(int i = 0; i < count; i++) {
				a[i] = rdQueue[i];
			}
			StdRandom.shuffle(a);
		}
		public boolean hasNext() {
			return n < count;
		}
		public void remove() {throw new UnsupportedOperationException();}
		public Item next() {
			if(!hasNext()) {throw new NoSuchElementException();}  
			return a[n++];
		}
	}
}
