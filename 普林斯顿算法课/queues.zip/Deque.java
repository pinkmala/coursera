import java.util.Iterator;
import java.util.NoSuchElementException;

public class Deque<Item> implements Iterable<Item> {
	private Node head;
	private Node tail;
	private int count;
	private class Node {
		private Item t;
		private Node next;
		private Node pre;
		public Node (Item t, Node next,Node pre) {
			this.t = t;
			this.next = next;
			this.pre= pre;
		}
	}
	public Deque() {
		head = null;
		tail = null;
		count = 0;
	}                           // construct an empty deque
	public boolean isEmpty() {
		return count == 0;
	}                 // is the deque empty?
	public int size() {
		return count;
	}                        // return the number of items on the deque
	public void addFirst(Item item) {
		if (item == null)  throw new IllegalArgumentException();
		if (head == null) {
			head = new Node(item, null, null);
			tail = head;
		}
		else {
			Node newNode = new Node(item, head, null);
			head.pre = newNode;
			head = newNode;
		}
		count++;
	}          // add the item to the front
	public void addLast(Item item) {
		if (item == null)  throw new IllegalArgumentException();
		if (tail == null) {
			tail = new Node(item, null, null);
			head = tail;
		}
		else {
			Node newNode = new Node(item, null, tail);
			tail.next = newNode;
			tail = newNode;
		}
		count++;
	}           // add the item to the end
	public Item removeFirst() {
		if (isEmpty()) {
			throw new  NoSuchElementException();
		}
		Node deleted = head;
		Item t = deleted.t;
		head = head.next;
        if (head == null) {
			tail = null;
		}
        else {head.pre = null;}
		count--;
		return t;
		
			
	}               // remove and return the item from the front
	public Item removeLast() {
		if (isEmpty()) {
			throw new  NoSuchElementException();
		}
		Node deleted = tail;
		Item t = deleted.t;
		tail = tail.pre;
		if (tail == null) {
			head = null;
		}
		else {tail.next = null;}
		count--;
		return t;
	}                // remove and return the item from the end
    // return an iterator over items in order from front to end
	@Override
	public Iterator<Item> iterator() {
		return new ListIterator();
	}

	    // an iterator, doesn't implement remove() since it's optional
	private class ListIterator implements Iterator<Item> {
		private Node current = head;
	    public boolean hasNext()  { return current != null;                     }
	    public void remove()  { throw new UnsupportedOperationException();  }

	    public Item next() {
	    if (!hasNext()) throw new NoSuchElementException();
	    Item t = current.t;
	    current = current.next; 
	    return t;
	    }
	}
}